<?php include_once("admin/includes/common_function.php") ?>
<footer>
    <div class="container">
        <div class="row justify-content-between">

            <div class="col-md-5">
                <h5>About</h5>
                <p>An Auto Parts Store is a retail establishment that primarily offers a wide range of components and accessories for vehicles. These stores provide essential items, including engine parts, brake systems, batteries, tires, and maintenance tools, catering to both professional mechanics and individual car enthusiasts. Customers can find products from various trusted brands, ensuring quality and reliability. Many auto parts stores also offer services such as guidance for selecting the right parts and tools for repairs, making them essential hubs for keeping vehicles running smoothly and efficiently.

                </p>
            </div>
            <div class="col-md-3">
                <h5>Links</h5>
                <ul>
                    <li>
                        <a href="about.php">About Us</a>
                    </li>
                    <li>
                        <a href="contact.php">Contact Us</a>
                    </li>


                </ul>
            </div>
            <div class="col-md-3">
                <h5>Contact</h5>
                <ul>
                    <li>
                        <a href="tel://<?php echo setting('phone'); ?>"><i class="fa fa-phone"></i> <?php echo setting('phone_number'); ?></a>
                    </li>
                    <li>
                        <a href="mailto:<?php echo setting('email'); ?>"><i class="fa fa-envelope"></i> <?php echo setting('email'); ?></a>
                    </li>
                </ul>

                <h5>Follow Us</h5>
                <ul class="social">
                    <li>
                        <a href="<?php echo setting('fb_url'); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo setting('insta_url'); ?>" target="_blank"><i class="fab fa-instagram"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo setting('yt_url'); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo setting('x_url'); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                    </li>
                </ul>
            </div>

        </div>
    </div>
    <p class="copyright">&copy; 2025 AutoZoneHub | Your Trusted Auto Parts Store. All rights reserved.</p>
</footer>
</div>