<?php
 session_start();

 define("BASE_PATH",dirname(dirname(__FILE__)));
 define("BASE_URL",'http://localhost/online_auto_parts');
 

 include_once(__DIR__."/connection.php");