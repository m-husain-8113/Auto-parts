<?php
ob_start();

include_once("includes/config.php");
include("includes/top.php");

$sql = "select * from orders";
$result = mysqli_query($conn,$sql);
$row = mysqli_num_rows($result);

$sql2 = "select * from orders where status = 'Delivered'";
$result2 = mysqli_query($conn,$sql2);
$row2 = mysqli_num_rows($result2);

$sql3 = "select * from orders where status = 'Pending'";
$result3 = mysqli_query($conn,$sql3);
$row3 = mysqli_num_rows($result3);

$sql4 = "select * from orders where status = 'Canceled'";
$result4 = mysqli_query($conn,$sql4);
$row4 = mysqli_num_rows($result4);

?>
<div class="page-wrapper">
    <div class="page-content">
        <h1 class="mb-5">Order Summary</h1>
        <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0 text-secondary"> Total Orders</p>
                                <h4 class="my-1"><?php echo $row ?></h4>
                            </div>
                            <div class="widgets-icon bg-light-success text-primary ms-auto">
                                <i class="bx bxs-shopping-bag-alt"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0 text-secondary"> Pending Orders</p>
                                <h4 class="my-1"><?php echo $row3 ?></h4>
                            </div>
                            <div class="widgets-icon bg-light-warning text-warning ms-auto">
                                <i class="bx bxs-cart-alt"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0 text-secondary"> Delivered Orders</p>
                                <h4 class="my-1"><?php echo $row2 ?></h4>
                            </div>
                            <div class="widgets-icon bg-light-success text-success ms-auto">
                                <i class="bx bxs-shopping-bag-alt"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0 text-secondary"> Canceled Orders</p>
                                <h4 class="my-1"><?php echo $row4 ?></h4>
                            </div>
                            <div class="widgets-icon bg-light-danger text-danger ms-auto">
                                <i class="bx bxs-shopping-bag-alt"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php
include("includes/footer.php");
include("includes/bottom.php");
?>