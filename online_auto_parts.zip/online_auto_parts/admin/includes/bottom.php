</div>
    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/jquery/jquery.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/node-waves/waves.min.js"></script>

    <!-- apexcharts -->
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/apexcharts/apexcharts.min.js"></script>

    

    <!-- App js -->
    <script src="<?php echo $adminBaseUrl ?>/assets/js/app.js"></script>
</body>

</html>