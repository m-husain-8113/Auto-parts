<?php
    include_once(__DIR__.'/../../includes/config.php');
    $adminBaseUrl = BASE_URL.'/admin';