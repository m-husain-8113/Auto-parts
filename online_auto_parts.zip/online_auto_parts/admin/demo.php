
//admin//include//
//bottom.php
</div>
    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/jquery/jquery.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/node-waves/waves.min.js"></script>

    <!-- apexcharts -->
    <script src="<?php echo $adminBaseUrl ?>/assets/libs/apexcharts/apexcharts.min.js"></script>

    

    <!-- App js -->
    <script src="<?php echo $adminBaseUrl ?>/assets/js/app.js"></script>
</body>

</html>
//common_function.php
<?php
 include_once("includes/config.php");
if(! function_exists('setting')){
    function setting($key,$default=null){
        global $conn;
        $sql="select * from settings where setting_name='".$key."'";
        $result=mysqli_query($conn,$sql);
        $row=mysqli_fetch_assoc($result);
        if($row){
            return $row['setting_value'];
        }
        return $default;
    }
}
?>
//config.php
<?php
    include_once(__DIR__.'/../../includes/config.php');
    $adminBaseUrl = BASE_URL.'/admin';
//footer.php
     </div>
</div>
<footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <script>document.write(new Date().getFullYear())</script> © moriya.
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end d-none d-sm-block">
                            Design & Develop by moriya
                        </div>
                    </div>
                </div>
            </div>
</footer>
</div>
//header.php

<?php
    include_once('includes/config.php');

    $sql = "select * from users where user_id = '".$_SESSION['admin_id']."'";
    $result = mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
?>
<header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box">
               
                <a href="index.php" class="logo logo-light">
                    <span class="logo-lg">
                        <img src="images/logo/admin-logo.jpg" alt="" height="19" style="height: 54px; width: 175px;">
                    </span>
                </a>
            </div>

            <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn">
                <i class="fa fa-fw fa-bars"></i>
            </button>

        </div>

        <div class="d-flex">

            <div class="dropdown d-inline-block d-lg-none ms-2">
                <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-search-dropdown"
                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="mdi mdi-magnify"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                    aria-labelledby="page-header-search-dropdown">

                    <form class="p-3">
                        <div class="form-group m-0">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search ..."
                                    aria-label="Recipient's username">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit"><i
                                            class="mdi mdi-magnify"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="dropdown d-none d-lg-inline-block ms-1">
                <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                    <i class="bx bx-fullscreen"></i>
                </button>
            </div>

            <div class="dropdown d-inline-block">
                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="rounded-circle header-profile-user" src="<?php echo isset($row['image'])?BASE_URL."/".$row['image']:""?>"
                        alt="Header Avatar">
                    <span class="d-none d-xl-inline-block ms-1" key="t-henry"><?php echo isset($row['image'])?$row['name']:""?></span>
                    <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end">
                    <!-- item-->
                    <a class="dropdown-item" href="profile.php"><i class="bx bx-user font-size-16 align-middle me-1"></i>
                        <span key="t-profile">Profile</span></a>
                        <a class="dropdown-item text-danger" href="logout.php"><i
                            class="bx bx-power-off font-size-16 align-middle me-1 text-danger"></i> <span
                            key="t-logout">Logout</span></a>
                </div>
            </div>


        </div>
    </div>
</header>
//message.php
<?php
    if(!empty($error))
    {?>
        <div class= "alert alert-danger alert-dismissible">
         <div class="text-danger"><?php echo $error ;?>

         </div>
         <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
         </div>
   <?php }
    if(!empty($success))
    {?>
        <div class= "alert alert-success alert-dismissible">
         <div class="text-success"><?php echo $success ;?>

         </div>
         <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
         </div>
   <?php }
    if(!empty($warning))
    {?>
        <div class= "alert alert-warning alert-dismissible">
         <div class="text-danger"><?php echo $warning ;?>

         </div>
         <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
         </div>
   <?php }
 //sidebar.php
<div class="vertical-menu">

    <div data-simplebar class="h-100">
      
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title" key="t-menu">Menu</li>
                <li class='mm-active'>
                    <a href="dashboard.php" class="waves-effect">
                        <i class="bx bx-calendar"></i>
                        <span key="t-dashboard">Dashboard</span>
                    </a>
                </li>
                <li class="mm-active">
                    <a href="banner.php" class="waves-effect">
                        <i class="fa fa-images"></i>
                        <span key="t-dashboard">Banner</span>
                    </a>
                </li>
                <li class="mm-active">
                    <a href="category.php" class="waves-effect">
                        <i class="fa fa-th-list"></i>
                        <span key="t-dashboard">Category</span>
                    </a>
                </li>
                
                <li class="mm-active">
                    <a href="product.php" class="waves-effect">
                        <i class="fab fa-product-hunt"></i>
                        <span key="t-dashboard">Product</span>
                    </a>
                </li>
                
                <li class="mm-active">
                    <a href="setting.php" class="waves-effect">
                        <i class="bx bx-wrench"></i>
                        <span key="t-dashboard">Setting</span>
                    </a>
                </li>
                <li class="mm-active">
                    <a href="orders_detail.php" class="waves-effect">
                        <i class="bx bxs-detail"></i>
                        <span key="t-dashboard">Orders</span>
                    </a>
                </li>
                <li class="mm-active">
                    <a href="feedback.php" class="waves-effect">
                        <i class="bx bx-conversation"></i>
                        <span key="t-dashboard">Feedback</span>
                    </a>
                </li>
                

            </ul>


        </div>
        <!-- Sidebar -->
    </div>
</div>
//top.php
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Auto_parts - Admin & Dashboard </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="images/logo/grocery.png">

    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.css" id="app-style" rel="stylesheet" type="text/css" />

</head>

<body data-sidebar="dark">

    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php
        
            include_once("includes/header.php");

            include_once("includes/sidebar.php");
        ?>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
    <?php
     if(empty($_SESSION['admin_id']))
     {
         header("Location: ".$adminBaseUrl."/index.php");
         exit;
     }
     
    ?>