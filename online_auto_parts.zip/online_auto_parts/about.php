<?php
ob_start();
include_once("includes/config.php");
include_once("includes/top.php");
?>
<div class='mt-5'>
    <img class='banner' src="./admin/images/banner/offer.jpg">
</div>
<section class="bg-leaf">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center mb-3">
                <h1 class="title text-uppercse mb-2 mb-5">AUTO PARTS</h1>
                <h5 class="mt-3 mb-5">
                    Orignal parts store
                </h5>
            </div>
        </div>
        <div class="row justify-content-center mb-5">
            <img src="./admin/images/banner/part2.jpg" alt="image" width="350px" height = "250px">
            <div class="col-md-6 ">
                <h5>Straight from the Manufacturer.</h5>
                <p>Our Manufacturer-to-Customer concept focuses on delivering high-quality auto parts directly from trusted manufacturers to your doorstep within just one day. This ensures you receive reliable and genuine products, straight from the source..</p>
                <p>Our Manufacturer-to-Customer concept focuses on delivering high-quality auto parts directly from trusted manufacturers to your doorstep within just one day. This ensures you receive reliable and genuine products, straight from the source..</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h5> Know Your Manufacturers.</h5>
                <p>We want you to know exactly who is making your auto parts by featuring manufacturer profiles on each product and a dedicated manufacturers' page. You’re welcome to explore their facilities and see the expertise and precision they put into crafting your parts.</p>
                <p>We want you to know exactly who is making your auto parts by featuring manufacturer profiles on each product and a dedicated manufacturers' page. You’re welcome to explore their facilities and see the expertise and precision they put into crafting your parts.</p>
                <p>We want you to know exactly who is making your auto parts by featuring manufacturer profiles on each product and a dedicated manufacturers' page. You’re welcome to explore their facilities and see the expertise and precision they put into crafting your parts.</p>
            </div>
            <img src="./admin/images/banner/part1.jpg" alt="image" width="350px" height = "250px">
        </div>
    </div>
</section>
<?php
include_once("includes/footer.php");
include_once("includes/bottom.php");
?>
