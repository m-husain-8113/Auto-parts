<?php
ob_start();
include_once("includes/config.php");
include_once("includes/top.php");

if (isset($_POST['submit'])) {
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    
    $sql = "select email from users where type = 'user'";
    $result = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_assoc($result))
    {
        $error = null;
        if($email == $row['email'])
        {
            if($password == $cpassword)
            {
                 $sql1 = "update users set password = '".$password."' where email = '".$email."' and type = 'user'";
                 $result1 = mysqli_query($conn,$sql1);
                 if($result1)
                 {
                     $success = "Password Forgot Successfully...!";
                 }  
            }
            else {
                $error_pass = "Paswword Doesn't Match";
            }
        }
        else{
            $error = "Email Are not Exist !..";
        }
    }

}
?>

<div id="page-content" class="page-content" style="margin-bottom: 300px;">
    <div class="banner">
        <div class="jumbotron jumbotron-bg text-center rounded-0" style="background-image: url('admin/images/bg-image/bg-forgot-password.jpg');">
            <div class="container">
                <h1 class="pt-5 mb-5">
                  Forgot Password
                </h1>

                <div class="card card-login mb-5">
                    <div class="card-body bg-dark">
                        <?php if(isset($success)){?>
                            <label class="bg-success alert"><?php echo $success;?></label>
                            <?php } ?>
                        <form class="form-horizontal" action="" method="post">
                            <div class="form-group row mt-3">
                                <div class="col-md-12">
                                    <input class="form-control" name="email" type="text" required placeholder="Enter Email">
                                </div>
                                <label for="" class="text-danger ml-3 mt-1"><?php echo isset($error)?$error:""?></label>
                            </div>
                            
                                                       
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input class="form-control" name="password" type="password" required placeholder="Password">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input class="form-control" name="cpassword" type="password" required placeholder="Confirm Password">
                                </div>
                                <label for="" class="text-danger ml-3 mt-1"><?php echo isset($error_pass)?$error_pass:""?></label>
                            </div>
                            <div class="form-group row text-center mt-4">
                                <div class="col-md-12">
                                    <button type="submit" name="submit" class="btn btn-primary btn-block text-uppercase">Forgot Password</button>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include_once("includes/footer.php");
include_once("includes/bottom.php");
?>
//index.php
<?php
include_once("includes/config.php");
include_once("includes/top.php");
$sql = "select * from banners where active=1";
$result = mysqli_query($conn, $sql);
$sql = "select * from categories where active=1";
$result1 = mysqli_query($conn, $sql);

?>

<div id="slider-container">
    <div id="slider" class="jumbotron-rg">
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="slide">
                <!-- Ensure image URL is constructed properly -->
                <img src="<?php echo htmlspecialchars(BASE_URL . '/' . $row['image']); ?>"
                    alt="Slide Image"
                    style="max-width: 100%; height: 400px;">
            </div>
        <?php } ?>
    </div>
    <!-- Navigation Arrows -->
    <div id="prev" onclick="prevSlide()">&#10094;</div>
    <div id="next" onclick="nextSlide()">&#10095;</div>
</div>

<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="title">categories</h2>
                <div class="product-carousel owl-carousel">
                    <?php while ($row1 = mysqli_fetch_assoc($result1)) { ?>
                        <div class="item">
                            <div class="card card-product">
                                <div class="card-badge" style="height:200px;">
                                    <a href="category.php?id=<?php echo $row1['category_id']; ?>">
                                        <img src="<?php echo BASE_URL . '/' . $row1['image'] ?>" alt="category images"
                                            class="card-img-top" style="height:200px;">
                                    </a>
                                </div>
                                <div class="card-body">
                                    <a href="category.php?id=<?php echo $row1['category_id']; ?>"
                                        class="btn btn-block btn-primary">
                                        <?php echo $row1['category_name'] ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?php
include_once("includes/footer.php");
include_once("includes/bottom.php");
?>