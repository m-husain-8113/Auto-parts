<?php
ob_start();
include_once("includes/config.php");
include_once("includes/top.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "select * from products where product_id = '$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $category_id = $row['category_id'];
    $product_id = $row['product_id'];
    $stock = $row['stock'];
    
}
$sql = "select * from products where category_id = $category_id";
$result1 = mysqli_query($conn, $sql);
?>

<div class='mt-5'>
    <img class='banner' src="./admin/images/banner/banner.jpg">
</div>

<div class="product-detail">

    <h2 class="title">Product Details</h2>
    <div class="container">
        <div class="row">

            <div class="col-sm-6">
                <div class="slider-zoom">
                    <div class="card">
                        <img alt="Detail Zoom thumbs image" src="<?php echo BASE_URL . "/" . $row['image']; ?>" style="width: 100%; margin-top: 50px;">
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <p>
                <h5><strong>Description</strong></h5><br>
                <?php echo $row['description']; ?>
                </p>
                <div class="row">
                    <div class="col-sm-6">
                        <p>
                            <strong>Price</strong><br><br>
                            <span class="price">₹ <?php echo $row['product_price'] ?></span>
                            <span class="old-price">₹ <?php echo $row['product_price'] * 2 ?></span>
                        </p>
                    </div>
                    <div class="col-sm-6 text-right">
                        <p>
                            <span class="stock <?php echo ($row['stock'] > 0) ? "available" : "empty"; ?>"><?php echo ($row['stock'] > 0) ? "In stock" : "out of stock"; ?> : <?php echo $row['stock']?></span>
                        </p>
                    </div>
                </div>

                <div style="display: none;" id="quantity">
                    <p class="">
                        <strong>Quantity</strong>
                    </p>
                    <div class="row">
                        <div class="col-sm-5">
                            <input value="1" class="vertical-spin" type="text" data-bts-button-down-class="btn btn-primary" data-bts-button-up-class="btn btn-primary" name="quantity">
                        </div>
                    </div>
                </div>
                <form  method="post">
                    <a class="mt-5 btn btn-primary btn-lg text-white" id="add1" onclick="addToCart();">
                        <i class="fa fa-shopping-basket"></i> Add to Cart
                    </a>
                </form>
                <a class="mt-5 btn btn-primary btn-lg text-white" id="add2" style="display: none;" onclick="addToCart();" href="cart.php?id=<?php echo $row['product_id'] ?>">
                    <i class="fa fa-shopping-basket"></i> Go to Cart
                </a>


            </div>

        </div>
    </div>
</div>

<section id="related-product">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="title">Related Products</h2>
                <div class="product-carousel owl-carousel">
                    <?php while ($row1 = mysqli_fetch_assoc($result1)) { ?>
                        <div class="item">
                            <a href="product.php?id=<?php echo $row1['product_id'] ?>">
                                <div class="card card-product">

                                    <img src="<?php echo BASE_URL . "/" . $row1['image'] ?>" alt="Card image 2" class="card-img-top" style="height: 250px; padding:25px">

                                    <div class="card-body">
                                        <h4 class="card-title">
                                            <a href="product.php?id=<?php echo $row1['product_id'] ?>"><?php echo $row1['product_name'] ?></a>
                                        </h4>
                                        <div class="card-price">
                                            <span class="discount">₹ <?php echo $row1['product_price'] * 5 ?></span>
                                            <span class="reguler">₹ <?php echo $row1['product_price'] ?></span>
                                        </div>
                                        <a href="product.php?id=<?php echo $row1['product_id'] ?>" class="btn btn-block btn-primary">
                                            Add to Cart
                                        </a>

                                    </div>

                                </div>
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
include_once("includes/footer.php");
include_once("includes/bottom.php");
?>
<script>
    function addToCart() {

        quantity = $('[name="quantity"]').val()
        if(<?php echo $stock ?> < quantity)
        {
            alert('Stock not available');
        }
        if(quantity == 0)
        {
            alert('Minimum 1 Product Select');
        }
       
        else{
            $.ajax({
            url: 'add_cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                product_id: "<?php echo $product_id ?>",
                quantity: quantity,
            },
            success: function(response) {

                $("#quantity").show();
                $("#add1").hide();
                $("#add2").show();
            },
             error: function(response) {
                 window.location.href = "login.php";
             }
        });
        }
    }
</script>